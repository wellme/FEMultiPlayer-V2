﻿import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Path2D;

import javax.swing.JPanel;

public class PlanCartesien extends JPanel {
	private static final long serialVersionUID = 1L;
	private Path2D.Double axes, ligneBrisee;
	private double xMin = -8, xMax = 8;
	private double yMin = -8, yMax = 8;
	private int nbSegmentsPourApproximer = 80;
	

	public PlanCartesien() {	
		setBackground(Color.white);
	}//fin du constructeur
	

	@Override
	public void paintComponent(Graphics g) {		
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;	
		
		creerAxes();
		creerApproxCourbe();
		
		g2d.translate(getWidth()/2.0, getHeight()/2.0); //pour recentrer
		g2d.scale(1, -1); 	//pour inverser le sens des y
	    
		//on dessine les axes
	    g2d.setColor(Color.blue);
	    g2d.draw(axes); 
	    
	    //on dessine la courbe
	    g2d.setColor(Color.red);
	    g2d.draw(ligneBrisee);   
	    
	}//fin paintComponent
	

	private void creerAxes() {
	    axes = new Path2D.Double ();
	    axes.moveTo( xMin, 0 );
	    axes.lineTo( xMax,  0 );
	    axes.moveTo( 0,  yMin );
	    axes.lineTo( 0,  yMax );

	}
	
	private void creerApproxCourbe() {
	    double x, y;

	    ligneBrisee = new Path2D.Double();
	    x = xMin;  //on commence a l'extreme gauche
	  	y = evalFonction(x);
	  	ligneBrisee.moveTo( x, y );
	
	    for (int k=1; k<nbSegmentsPourApproximer+1; k++) {
	   		x = xMin + k*(xMax-xMin)/nbSegmentsPourApproximer;   //on ajoute un intervalle fixe en x	
	    	y = evalFonction(x);
	    	ligneBrisee.lineTo( x, y); 
	    			
	    }//fin for
	}
	
	
	private double evalFonction(double x) {
		return(0.2*x*x+ x + 1);
	}
	
	
	
}//fin classe