
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;


public class Application extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private Scene dessinObjetsDessinables ;


	/**
	 * Demarrage
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Application frame = new Application();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Constructeur
	 */
	public Application() {
		setTitle("particule dans avec ModelePhysique");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 347, 317);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		dessinObjetsDessinables = new Scene();
		dessinObjetsDessinables.setBounds(19, 11, 293, 199);
		contentPane.add(dessinObjetsDessinables);
		
		JLabel lblNewLabel = new JLabel("Cette sc\u00E8ne montre 3 microns en largeur");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(22, 240, 286, 14);
		contentPane.add(lblNewLabel);
	
	}
}
