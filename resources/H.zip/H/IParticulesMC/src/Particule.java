

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;

public class Particule {
	private final double DIAMETRE = 0.8;  
	private double x,y;
	private Ellipse2D.Double cercle;
	private Line2D.Double ligne1, ligne2;
	private double charge; //charge en Coulombs, positive ou n�gative
	private final double TOLERANCE = 1e-13;

	public Particule(double x, double y) {
		this.x = x;
		this.y = y;	
		this.charge = 0; //neutre par defaut
	}
	
	public Particule(double x, double y, double charge) {
		this.x = x;
		this.y = y;
		this.charge = charge;
	}
	
	private void creerRepresentationGeometrique() {
		cercle = new Ellipse2D.Double(x, y, DIAMETRE, DIAMETRE);
		ligne1 = new Line2D.Double(x+DIAMETRE/2, y, x+DIAMETRE/2, y+DIAMETRE);
		ligne2 = new Line2D.Double(x, y+DIAMETRE/2, x+DIAMETRE, y+DIAMETRE/2);
	}

	public void dessiner(Graphics2D g2d) {
		creerRepresentationGeometrique();
		Color couleurCourante = g2d.getColor();
		if (charge<0-TOLERANCE) {
			g2d.setColor(Color.blue);
		} else if (charge>0+TOLERANCE) {
			g2d.setColor(Color.red);
		} else {
			g2d.setColor(Color.white);
		}
	
		g2d.draw(cercle);
		g2d.draw(ligne1);
		g2d.draw(ligne2);

		
		g2d.setColor(couleurCourante);
		
	}//fin methode

	public double getCharge() {
		return charge;
	}

	public void setCharge(double charge) {
		this.charge = charge;
	}


}//fin classe





