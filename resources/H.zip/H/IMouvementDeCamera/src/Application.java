

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Application extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private CameraAnimee panelCamera;
	private JButton btnGo;


	/**
	 * D�marrage
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {				
					Application frame = new Application();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Constructeur de l'application
	 */
	public Application() {
		setTitle("Mouvement de cam\u00E9ra \u00E0 l'aide de la matrice monde-vers-composant");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 645, 515);	
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		panelCamera = new CameraAnimee();
		panelCamera.setBounds(21, 11, 587, 400);
		contentPane.add(panelCamera);
		panelCamera.setLayout(null);
		
		btnGo = new JButton("Animer la position de la cam\u00E9ra");
		btnGo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				panelCamera.demarrer();
				btnGo.setEnabled(false);
			}
		});
		btnGo.setBounds(175, 422, 264, 44);
		contentPane.add(btnGo);
	
	}//fin constructeur
}//fin classe


