
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JPanel;


public class ZoneDessinBloc extends JPanel {
	private static final long serialVersionUID = 1L;
	
	//le monde aura 8 m�tres en largeur
	private final double LARGEUR_MONDE = 8;

	private final double COTE_BLOC = 0.35;	
	private final double POSX_INITIALE = 0.45;
	private double posx = POSX_INITIALE;

	public ZoneDessinBloc() {
		setBackground(new Color(30, 144, 255));
		setPreferredSize(new Dimension(700,80));
	}//fin constructeur
	
	
	@Override
	public void paintComponent(Graphics g) {	
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;

		//ModelePhysique modele = new ModelePhysique(getWidth(), getHeight(), ????); //compl�ter le dernier param�tre
		//AffineTransform mat = modele.    //compl�ter l'appel
		
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
		
		Rectangle2D.Double rect = new Rectangle2D.Double(posx, 0, COTE_BLOC, COTE_BLOC);
		g2d.setColor(Color.yellow);
		g2d.draw(rect); 

		//On �crit l'�chelle en texte graphique.
		//Pour la simplicite, on exprime les positions du texte en pixels et non en unites reelles (approche mixte)
		g2d.drawString("0m", 7, getHeight()-10);  //rappel: avec drqawString, on sp�cifie le coin inf�rieur-gaiche du texte, en pixels
		String leTexte = LARGEUR_MONDE+"m";
		g2d.drawString(leTexte, getWidth()-32, getHeight()-10) ;; 
		
	}//fin methode


	public void deplacer(double deplacementEnMetres) {
		
	}


	public void retablir() {
		
	}
	
	
}//fin classe

