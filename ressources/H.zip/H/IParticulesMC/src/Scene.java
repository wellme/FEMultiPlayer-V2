
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

import javax.swing.JPanel;

public class Scene extends JPanel {
	private static final long serialVersionUID = -682431625659730792L;
	private double largeurDuMonde = 3;


	public Scene() {
		setBackground(Color.black);
		setLayout(null);
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;
		
		ModelePhysique modele = new ModelePhysique(getWidth(), getHeight(), largeurDuMonde);
		AffineTransform mat = modele.getMatMC();
	
		Particule part = new Particule(1, 0.4, 1.5);
		part.dessiner(g2d);
		
	}//fin methode
	
}//fin classe
