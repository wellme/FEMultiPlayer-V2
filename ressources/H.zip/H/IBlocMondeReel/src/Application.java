

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.SwingConstants;
import java.awt.Font;


public class Application extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lblEntrezLeDplacement;
	private JTextField txtDeplacement;
	private ZoneDessinBloc monBloc;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Application frame = new Application();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Constructeur
	 */
	public Application() {
		setTitle("Mod\u00E9lisation de mesures r\u00E9elles");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 742, 239);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		monBloc = new ZoneDessinBloc();
		monBloc.setBounds(10, 11, 706, 137);
		contentPane.add(monBloc);
		
		lblEntrezLeDplacement = new JLabel("Entrez un d\u00E9placement \u00E0 appliquer (en m):");
		lblEntrezLeDplacement.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblEntrezLeDplacement.setHorizontalAlignment(SwingConstants.CENTER);
		lblEntrezLeDplacement.setForeground(Color.WHITE);
		lblEntrezLeDplacement.setBounds(10, 159, 305, 31);
		contentPane.add(lblEntrezLeDplacement);
		
		txtDeplacement = new JTextField();
		txtDeplacement.setHorizontalAlignment(SwingConstants.CENTER);
		txtDeplacement.setForeground(Color.BLUE);
		txtDeplacement.setFont(new Font("Tahoma", Font.BOLD, 14));
		txtDeplacement.setText("0.12");
		txtDeplacement.setBounds(309, 159, 86, 31);
		contentPane.add(txtDeplacement);
		txtDeplacement.setColumns(10);
		
		JButton btnBouger = new JButton("Bouger!");
		btnBouger.setForeground(Color.BLUE);
		btnBouger.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//debut
				
				//fin
			}
		});
		btnBouger.setBounds(405, 158, 86, 31);
		contentPane.add(btnBouger);
		
		JButton btnRetablir = new JButton("R\u00E9tablir");
		btnRetablir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//debut
			
				//fin
			}
		});
		btnRetablir.setBounds(540, 158, 86, 31);
		contentPane.add(btnRetablir);
		
		JButton btnQuitter = new JButton("Quitter");
		btnQuitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		btnQuitter.setBounds(630, 158, 86, 31);
		contentPane.add(btnQuitter);
	}
}
