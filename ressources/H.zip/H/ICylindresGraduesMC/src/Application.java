
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JToggleButton;
import java.awt.Color;
import javax.swing.JSpinner;
import java.awt.Font;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;


public class Application extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private Scene sceneCylindres ;
	private JLabel lblLargeurDuMonde;
	private JSpinner spnLargeur;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Application frame = new Application();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Application() {
		setTitle("Classes dessinables avec transformations encapsul\u00E9es");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 639, 491);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		sceneCylindres = new Scene();
		sceneCylindres.setBackground(Color.BLACK);
		sceneCylindres.setBounds(23, 24, 427, 384);
		contentPane.add(sceneCylindres);
		
		JButton btnQuitter = new JButton("Quitter");
		btnQuitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		btnQuitter.setBounds(216, 419, 89, 23);
		contentPane.add(btnQuitter);
		
		lblLargeurDuMonde = new JLabel("Largeur du monde:");
		lblLargeurDuMonde.setBounds(460, 72, 135, 14);
		contentPane.add(lblLargeurDuMonde);
		
		spnLargeur = new JSpinner();
		spnLargeur.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				//debut
				
				//fin
			}
		});
		spnLargeur.setModel(new SpinnerNumberModel(new Double(40), null, null, new Double(1)));
		spnLargeur.setFont(new Font("Tahoma", Font.BOLD, 18));
		spnLargeur.setBounds(485, 115, 64, 35);
		contentPane.add(spnLargeur);
		
		JLabel lblCm = new JLabel("cm");
		lblCm.setBounds(567, 120, 46, 14);
		contentPane.add(lblCm);
		
	
	}
}
