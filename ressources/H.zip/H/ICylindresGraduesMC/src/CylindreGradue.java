

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

public class CylindreGradue {

	private double x,y;
	private double largeur, hauteur, hauteurOval;

	private Rectangle2D.Double corps;
	private Ellipse2D.Double ovalDessusDessous;
	private Line2D.Double graduation;
	
	private final int NB_GRADUATIONS_DEFAUT = 4;
	private int nbGraduations;
	private int facteurEspacementGrad = 5;

	
	/**
	 * 
	 * @param x Le x du coin sup�rieur gauche du cylindre, incluant l'oval dessin� sur le dessus
	 * @param y Le y du coin sup�rieur gauche du cylindre, incluant l'oval dessin� sur le dessus
	 * @param largeur La largeur du cylindre
	 * @param hauteur La hauteur du cylindre seulement, sans les ellipses au dessus et au dessous
	 */
	public CylindreGradue(double x, double y, double largeur, double hauteur) {
		this.x = x;
		this.y = y;
		this.largeur = largeur;
		this.hauteur = hauteur;
		this.nbGraduations = NB_GRADUATIONS_DEFAUT;
	}
	

	
	private void creerRepresentationGeometrique() {
		hauteurOval = largeur/3;
		ovalDessusDessous = new Ellipse2D.Double(x, y, largeur, hauteurOval);
		corps = new Rectangle2D.Double(x, y+hauteurOval/2, largeur, hauteur);
		graduation = new Line2D.Double(x, y, x+largeur/4, y);
	}
		
	
	public void dessiner(Graphics2D g2d, AffineTransform mat) {
	
		Color couleurALentree = g2d.getColor();  //n�cessaire car certaines parties sont en noir
		creerRepresentationGeometrique();
		
		//corps du cylindre
		g2d.draw(mat.createTransformedShape(corps));
		
	
		//dessus
		g2d.setColor(Color.black); //pour effacer le dessus du rectangle
		g2d.fill(mat.createTransformedShape(ovalDessusDessous));
		g2d.setColor(couleurALentree); 
		g2d.draw(mat.createTransformedShape(ovalDessusDessous));
		
		//dessous
		mat.translate(0, hauteur);
		g2d.fill(mat.createTransformedShape(ovalDessusDessous));
		g2d.setColor(couleurALentree); 
		g2d.draw(mat.createTransformedShape(ovalDessusDessous));
		
	
		//graduations
		mat.translate(largeur*3/4, -hauteur+hauteurOval);
		mat.translate(0, 2*hauteur/(nbGraduations+facteurEspacementGrad));
		for (int k=0; k<nbGraduations; k++ ) {
			mat.translate(0, hauteur/(nbGraduations+facteurEspacementGrad));
			g2d.draw(mat.createTransformedShape(graduation));
		}

		g2d.setColor(couleurALentree); //restaurer la couleur en cours
	}

	public int getNbGraduations() {
		return nbGraduations;
	}

	public void setNbGraduations(int nbGraduations) {
		this.nbGraduations = nbGraduations;
	}


}//fin classe





