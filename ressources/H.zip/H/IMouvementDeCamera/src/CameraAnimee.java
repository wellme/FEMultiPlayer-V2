

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JPanel;


public class CameraAnimee extends JPanel implements Runnable {
	private static final long serialVersionUID = 1L;
	private Thread processus = null;
	private double posCamX = 0; //au debut, le coin de la portion visible est a l'origine
	private double posCamY = 0;
	
	private final int LARGEUR_MONDE = 8;  //le panel montre en tout temps 8 m�tres du monde r�el en largeur
	
	private ModelePhysique modele;

	public CameraAnimee() {
		setBackground(Color.BLACK);
	} //fin du constructeur


	@Override
	public void paintComponent(Graphics g) {		
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		
		modele = new ModelePhysique(getWidth(), getHeight(), posCamX, posCamY, LARGEUR_MONDE);
		AffineTransform matMC = modele.getMatMC();
		
		Ellipse2D.Double cercle1 = new Ellipse2D.Double(1, 1, 1.2, 1.2); //cercle de 1.2 m�tres de diam�tre
		g2d.setColor(Color.blue);
		g2d.fill(matMC.createTransformedShape(cercle1));
		
		Ellipse2D.Double cercle2 = new Ellipse2D.Double(2.2, 1, 1.2, 1.2);
		g2d.setColor(Color.yellow);
		g2d.fill(matMC.createTransformedShape(cercle2));
				
		Ellipse2D.Double cercle3 = new Ellipse2D.Double(3.4, 1, 1.2, 1.2);
		g2d.setColor(Color.blue);
		g2d.fill(matMC.createTransformedShape(cercle3));
		
		Rectangle2D.Double carre = new Rectangle2D.Double(5, 3, 0.5, 0.5);
		g2d.setColor(Color.red);
		g2d.fill(matMC.createTransformedShape(carre));
		
		Ellipse2D.Double cercle4 = new Ellipse2D.Double(6, 3, 3.5, 3.5);
		g2d.setColor(Color.red);
		g2d.fill(matMC.createTransformedShape(cercle4));
		
		//non visible initialement, mais le devriendra quand on changera la "position de la camera"
		Ellipse2D.Double cercle5 = new Ellipse2D.Double(10, 3, 3.5, 3.5);
		g2d.setColor(Color.magenta);
		g2d.fill(matMC.createTransformedShape(cercle5));
		
	}//fin paintComp

	@Override
	public void run() {
		while (true) {
			
			/* ci-dessous: animez la "position de la camera" en faisant varier posCamX et/ou posCamY de quelques centim�tres a la fois */
			
		    repaint();
			
			try {
				Thread.sleep(40);
			} 
			catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		}//fin while
		
	} // fin run


	
	public void demarrer() {
		processus = new Thread(this);
		processus.start();
		System.out.println("Animation d�mar�e...");
	}
	
	
}//fin classe